//
//  HomeVC.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class HomeVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        displayUsers()

        // Do any additional setup after loading the view.
    }

        func displayUsers(){
            var userList = User.getAllUsers()
            
            for User in userList.values{
                print("Name : \(User.name)")
                print("Address : \(User.address)")
                print("Contact Number : \(User.contactNumber)")
                print("Postal Code : \(User.postalCode)")
                print("City : \(User.city)")
                print("Date : \(User.DOB)")
                
            }
        }

}
