//
//  User.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-08.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class User{
    var name: String!
    var contactNumber: String!
    var address: String!
    var postalCode: String!
    var city:   String!
    var email: String!
    var password: String!
    var DOB: Date!
    var gender: String!
    private static var userList = [String:User]()
    
    
    init(){
        self.name = ""
        self.contactNumber = ""
        self.address = ""
        self.postalCode = ""
        self.city = ""
        self.email = ""
        self.password = ""
        self.gender = ""
        self.DOB = Date()
        
    }

    init( _ name:String, _address:String, _contactNumber:String,_postalCode:String,_city:String,_email:String,_password:String,_gender:String,_DOB:Date){
        self.name = name
        self.address = _address
        self.contactNumber = _contactNumber
        self.postalCode = _postalCode
        self.city = _city
        self.email = _email
        self.password = _password
        self.gender = _gender
        self.DOB = Date()
    }
    
    static func addUser(newUser: User) -> Bool {
        if self.userList[newUser.email] == nil{
        self.userList[newUser.email] = newUser
            return true
        
        }
        return false
    }
    
    static func getAllUsers()-> [String: User]{
        return userList
    }

    static func searchUser(userEmail:String) -> User {
        if self.userList[userEmail] != nil {
            return self.userList[userEmail]!
        }
        return User()
        }
    
    }
    


















