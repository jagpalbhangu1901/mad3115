//
//  LoginVC.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {

    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet var switchRemember: UISwitch!
    
    @IBAction func btnSignUp(_ sender: UIButton) {
        
        let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        let SignUpVC = mainSB.instantiateViewController(withIdentifier: "SignUpScene" )
        
        
        navigationController?.pushViewController( SignUpVC , animated: true)
    }
    
    
    @IBAction func btnSignIn(_ sender: UIButton) {
        if validateUser(){
            
            if switchRemember.isOn{
                //SAVE Data
                UserDefaults.standard.set(txtEmail.text, forKey: "Email")
                UserDefaults.standard.set(txtPassword.text, forKey: "Password")
            }else{
                //remove data
                UserDefaults.standard.removeObject(forKey: "Email")
                UserDefaults.standard.removeObject(forKey: "Password")
            }
            
            
            let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            
            let HomeVC = mainSB.instantiateViewController(withIdentifier: "HomeScene" )
            
//            self.present(HomeVC, animated: true, completion: nil)
            
            navigationController?.pushViewController(HomeVC, animated: true)
            
            
        }else{
            let infoAlert = UIAlertController(title: "Invalid User", message: "Incorret Username and/or Password " , preferredStyle: .alert)
            infoAlert.addAction(UIAlertAction(title: "Retry" , style: .default, handler: nil))
            self.present(infoAlert, animated: true, completion: nil)
        }
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let email = UserDefaults.standard.string(forKey: "Email"){
            txtEmail.text = email
        }
        
        if let password = UserDefaults.standard.value(forKey: "Password"){
            txtPassword.text = password as? String
        }
        
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func validateUser() -> Bool{
        if txtEmail.text == "test"  && txtPassword.text == "test"{
            return true
        }else{
            return false
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
